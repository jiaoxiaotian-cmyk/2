
  # 浏览器FPS游戏制作

  This is a code bundle for 浏览器FPS游戏制作. The original project is available at https://www.figma.com/design/4IeiolUnMtrKfLzEAH90Iu/%E6%B5%8F%E8%A7%88%E5%99%A8FPS%E6%B8%B8%E6%88%8F%E5%88%B6%E4%BD%9C.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  