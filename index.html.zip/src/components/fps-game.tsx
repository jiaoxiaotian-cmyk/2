import { useEffect, useRef, useState, useCallback } from "react";
import * as THREE from "three";
import { PointerLockControls } from "three/examples/jsm/controls/PointerLockControls.js";
import { Crosshair, Volume2, VolumeX } from "lucide-react";
import { Button } from "./ui/button";

interface Target {
  mesh: THREE.Mesh;
  id: string;
  hit: boolean;
}

export function FPSGame() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [ammo, setAmmo] = useState(30);
  const [remainingTargets, setRemainingTargets] = useState(15);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const soundEnabledRef = useRef(true);
  
  const gameStateRef = useRef({
    scene: null as THREE.Scene | null,
    camera: null as THREE.PerspectiveCamera | null,
    renderer: null as THREE.WebGLRenderer | null,
    controls: null as PointerLockControls | null,
    targets: [] as Target[],
    moveForward: false,
    moveBackward: false,
    moveLeft: false,
    moveRight: false,
    canJump: true,
    velocity: new THREE.Vector3(),
    direction: new THREE.Vector3(),
    raycaster: new THREE.Raycaster(),
    clock: new THREE.Clock(),
    ammo: 30,
  });

  const playShootSound = useCallback(() => {
    if (!soundEnabledRef.current) return;
    
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 200;
      oscillator.type = "sawtooth";

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(
        0.01,
        audioContext.currentTime + 0.1
      );

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.1);
    } catch (e) {
      console.log("Audio not supported");
    }
  }, []);

  useEffect(() => {
    soundEnabledRef.current = soundEnabled;
  }, [soundEnabled]);

  useEffect(() => {
    if (!containerRef.current) return;

    // 初始化场景
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb);
    scene.fog = new THREE.Fog(0x87ceeb, 0, 750);

    // 初始化相机
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.y = 10;

    // 初始化渲染器
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    containerRef.current.appendChild(renderer.domElement);

    // 添加光源
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(50, 100, 50);
    directionalLight.castShadow = true;
    directionalLight.shadow.camera.left = -100;
    directionalLight.shadow.camera.right = 100;
    directionalLight.shadow.camera.top = 100;
    directionalLight.shadow.camera.bottom = -100;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    scene.add(directionalLight);

    // 创建地面
    const groundGeometry = new THREE.PlaneGeometry(200, 200);
    const groundMaterial = new THREE.MeshStandardMaterial({
      color: 0x4a7c59,
      roughness: 0.8,
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // 添加网格辅助线
    const gridHelper = new THREE.GridHelper(200, 50, 0x000000, 0x000000);
    gridHelper.material.opacity = 0.2;
    gridHelper.material.transparent = true;
    scene.add(gridHelper);

    // 创建墙壁
    const wallMaterial = new THREE.MeshStandardMaterial({
      color: 0x808080,
      roughness: 0.7,
    });

    // 创建一些障碍物/掩体
    for (let i = 0; i < 10; i++) {
      const width = Math.random() * 5 + 3;
      const height = Math.random() * 4 + 2;
      const depth = Math.random() * 5 + 3;
      
      const wallGeometry = new THREE.BoxGeometry(width, height, depth);
      const wall = new THREE.Mesh(wallGeometry, wallMaterial);
      
      const angle = (i / 10) * Math.PI * 2;
      const radius = 30 + Math.random() * 40;
      wall.position.x = Math.cos(angle) * radius;
      wall.position.z = Math.sin(angle) * radius;
      wall.position.y = height / 2;
      wall.castShadow = true;
      wall.receiveShadow = true;
      scene.add(wall);
    }

    // 创建目标
    const targets: Target[] = [];
    const targetColors = [0xff0000, 0x00ff00, 0x0000ff, 0xffff00, 0xff00ff];
    
    for (let i = 0; i < 15; i++) {
      const targetGeometry = new THREE.BoxGeometry(2, 2, 2);
      const targetMaterial = new THREE.MeshStandardMaterial({
        color: targetColors[i % targetColors.length],
        emissive: targetColors[i % targetColors.length],
        emissiveIntensity: 0.3,
      });
      const target = new THREE.Mesh(targetGeometry, targetMaterial);
      
      const angle = (i / 15) * Math.PI * 2;
      const radius = 20 + Math.random() * 60;
      target.position.x = Math.cos(angle) * radius;
      target.position.z = Math.sin(angle) * radius;
      target.position.y = 2 + Math.random() * 3;
      target.castShadow = true;
      target.userData.isTarget = true;
      scene.add(target);
      
      targets.push({
        mesh: target,
        id: `target-${i}`,
        hit: false,
      });
    }

    // 初始化控制器
    const controls = new PointerLockControls(camera, renderer.domElement);

    const handleLock = () => {
      setIsPlaying(true);
    };

    const handleUnlock = () => {
      setIsPlaying(false);
    };

    controls.addEventListener("lock", handleLock);
    controls.addEventListener("unlock", handleUnlock);

    // 保存到ref
    gameStateRef.current.scene = scene;
    gameStateRef.current.camera = camera;
    gameStateRef.current.renderer = renderer;
    gameStateRef.current.controls = controls;
    gameStateRef.current.targets = targets;
    gameStateRef.current.ammo = 30;

    // 键盘事件
    const onKeyDown = (event: KeyboardEvent) => {
      switch (event.code) {
        case "KeyW":
        case "ArrowUp":
          gameStateRef.current.moveForward = true;
          break;
        case "KeyS":
        case "ArrowDown":
          gameStateRef.current.moveBackward = true;
          break;
        case "KeyA":
        case "ArrowLeft":
          gameStateRef.current.moveLeft = true;
          break;
        case "KeyD":
        case "ArrowRight":
          gameStateRef.current.moveRight = true;
          break;
        case "Space":
          if (gameStateRef.current.canJump) {
            gameStateRef.current.velocity.y += 150;
            gameStateRef.current.canJump = false;
          }
          break;
        case "KeyR":
          // 重新装弹
          gameStateRef.current.ammo = 30;
          setAmmo(30);
          break;
      }
    };

    const onKeyUp = (event: KeyboardEvent) => {
      switch (event.code) {
        case "KeyW":
        case "ArrowUp":
          gameStateRef.current.moveForward = false;
          break;
        case "KeyS":
        case "ArrowDown":
          gameStateRef.current.moveBackward = false;
          break;
        case "KeyA":
        case "ArrowLeft":
          gameStateRef.current.moveLeft = false;
          break;
        case "KeyD":
        case "ArrowRight":
          gameStateRef.current.moveRight = false;
          break;
      }
    };

    // 鼠标点击射击
    const onMouseClick = () => {
      if (gameStateRef.current.ammo <= 0) return;

      gameStateRef.current.ammo = Math.max(0, gameStateRef.current.ammo - 1);
      setAmmo(gameStateRef.current.ammo);

      // 射线检测
      gameStateRef.current.raycaster.setFromCamera(
        new THREE.Vector2(0, 0),
        camera
      );

      const intersects = gameStateRef.current.raycaster.intersectObjects(
        gameStateRef.current.targets.map((t) => t.mesh)
      );

      if (intersects.length > 0) {
        const hitObject = intersects[0].object as THREE.Mesh;
        const target = gameStateRef.current.targets.find(
          (t) => t.mesh === hitObject && !t.hit
        );

        if (target) {
          target.hit = true;
          setScore((prev) => prev + 10);
          setRemainingTargets((prev) => prev - 1);

          // 击中效果
          const material = target.mesh.material as THREE.MeshStandardMaterial;
          material.emissiveIntensity = 1;

          setTimeout(() => {
            scene.remove(target.mesh);
          }, 100);
        }
      }

      // 射击音效
      playShootSound();
    };

    document.addEventListener("keydown", onKeyDown);
    document.addEventListener("keyup", onKeyUp);
    renderer.domElement.addEventListener("click", onMouseClick);

    // 游戏循环
    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);

      const delta = gameStateRef.current.clock.getDelta();

      if (controls.isLocked) {
        const { velocity, direction } = gameStateRef.current;

        direction.z = Number(gameStateRef.current.moveForward) - Number(gameStateRef.current.moveBackward);
        direction.x = Number(gameStateRef.current.moveRight) - Number(gameStateRef.current.moveLeft);
        direction.normalize();

        const speed = 100.0;

        if (gameStateRef.current.moveForward || gameStateRef.current.moveBackward) {
          velocity.z -= direction.z * speed * delta;
        }
        if (gameStateRef.current.moveLeft || gameStateRef.current.moveRight) {
          velocity.x -= direction.x * speed * delta;
        }

        // 重力
        velocity.y -= 9.8 * 100 * delta;

        controls.moveRight(-velocity.x * delta);
        controls.moveForward(-velocity.z * delta);

        camera.position.y += velocity.y * delta;

        if (camera.position.y < 10) {
          velocity.y = 0;
          camera.position.y = 10;
          gameStateRef.current.canJump = true;
        }

        // 摩擦力
        velocity.x *= 0.9;
        velocity.z *= 0.9;

        // 旋转目标
        gameStateRef.current.targets.forEach((target) => {
          if (!target.hit) {
            target.mesh.rotation.y += delta * 0.5;
          }
        });
      }

      renderer.render(scene, camera);
    };

    animate();

    // 窗口大小调整
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener("resize", handleResize);

    // 清理
    return () => {
      cancelAnimationFrame(animationId);
      controls.removeEventListener("lock", handleLock);
      controls.removeEventListener("unlock", handleUnlock);
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("keyup", onKeyUp);
      renderer.domElement.removeEventListener("click", onMouseClick);
      window.removeEventListener("resize", handleResize);
      
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
      
      renderer.dispose();
    };
  }, [playShootSound]);

  const startGame = () => {
    if (gameStateRef.current.controls) {
      gameStateRef.current.controls.lock();
    }
  };

  return (
    <div className="relative w-full h-full">
      <div ref={containerRef} className="w-full h-full" />

      {/* 开始界面 */}
      {!isPlaying && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/70">
          <div className="text-center space-y-6 p-8">
            <h1 className="text-white">FPS 射击游戏</h1>
            <div className="text-white/80 space-y-2">
              <p>WASD - 移动</p>
              <p>鼠标 - 视角</p>
              <p>左键 - 射击</p>
              <p>空格 - 跳跃</p>
              <p>R - 重新装弹</p>
              <p>ESC - 暂停</p>
            </div>
            <Button onClick={startGame} size="lg" className="mt-4">
              开始游戏
            </Button>
          </div>
        </div>
      )}

      {/* 游戏HUD */}
      {isPlaying && (
        <>
          {/* 准星 */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
            <div className="relative w-8 h-8">
              <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-white/70" />
              <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-white/70" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-1 rounded-full bg-red-500" />
            </div>
          </div>

          {/* 状态栏 */}
          <div className="absolute top-4 left-4 space-y-2">
            <div className="bg-black/50 text-white px-4 py-2 rounded-lg backdrop-blur-sm">
              <div className="flex items-center gap-2">
                <span>得分:</span>
                <span>{score}</span>
              </div>
            </div>
            <div className="bg-black/50 text-white px-4 py-2 rounded-lg backdrop-blur-sm">
              <div className="flex items-center gap-2">
                <span>弹药:</span>
                <span className={ammo <= 5 ? "text-red-400" : ""}>{ammo}/30</span>
              </div>
            </div>
            <div className="bg-black/50 text-white px-4 py-2 rounded-lg backdrop-blur-sm">
              <div className="flex items-center gap-2">
                <span>剩余目标:</span>
                <span>{remainingTargets}</span>
              </div>
            </div>
          </div>

          {/* 音效控制 */}
          <div className="absolute top-4 right-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="bg-black/50 text-white hover:bg-black/70 backdrop-blur-sm"
            >
              {soundEnabled ? <Volume2 /> : <VolumeX />}
            </Button>
          </div>

          {/* 低弹药警告 */}
          {ammo <= 5 && (
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 bg-red-600/80 text-white px-6 py-3 rounded-lg backdrop-blur-sm animate-pulse">
              弹药不足！按 R 重新装弹
            </div>
          )}

          {/* 胜利提示 */}
          {remainingTargets === 0 && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/70">
              <div className="text-center space-y-4 p-8 bg-black/50 rounded-lg backdrop-blur-sm">
                <h2 className="text-white">恭喜！</h2>
                <p className="text-white/80">你击败了所有目标！</p>
                <p className="text-white">最终得分: {score}</p>
                <Button onClick={() => window.location.reload()} size="lg">
                  重新开始
                </Button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}