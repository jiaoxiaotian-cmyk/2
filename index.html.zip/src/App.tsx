import { FPSGame } from "./components/fps-game";

export default function App() {
  return (
    <div className="w-full h-screen overflow-hidden">
      <FPSGame />
    </div>
  );
}
